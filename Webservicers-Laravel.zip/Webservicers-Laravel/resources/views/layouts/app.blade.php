<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>@yield('title', $siteName . ' — Websites, SEO &amp; Advertising Experts')</title>
  <meta name="description" content="@yield('description', $siteDescription)" />
  <meta name="theme-color" content="#081512" />
  <link rel="icon" href="/assets/img/favicon.svg" type="image/svg+xml" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="/assets/css/styles.css" />
  <link rel="stylesheet" href="/assets/css/pages.css" />
  <script>document.documentElement.classList.add('js');</script>
</head>
<body class="@yield('body_class')">
  <a class="skip-link" href="#main">Skip to content</a>

  <!-- ============ HEADER ============ -->
  <header class="site-header" id="top">
    <div class="container">
      <div class="header-bar">
        <a class="brand" href="{{ route('home') }}" aria-label="WebServicers — home">
          <span class="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 40 40" fill="none">
              <rect width="40" height="40" rx="12" fill="url(#wsMark)"/>
              <path d="M9.5 13.2 14.9 26.8 20 17.6 25.1 26.8 30.5 13.2" stroke="#fff" stroke-width="3.1" stroke-linecap="round" stroke-linejoin="round"/>
              <circle cx="34.6" cy="7.6" r="2.2" fill="#E4FF6A"/>
              <defs>
                <linearGradient id="wsMark" x1="4" y1="2" x2="36" y2="40" gradientUnits="userSpaceOnUse">
                  <stop stop-color="#0C7C5A"/>
                  <stop offset="1" stop-color="#043B2A"/>
                </linearGradient>
              </defs>
            </svg>
          </span>
          <span class="brand-text"><span class="brand-word">Web</span><span class="brand-word--accent">Servicers</span></span>
        </a>

        <nav class="nav" id="primary-nav" aria-label="Main navigation">
          <ul class="nav-list">
            <li class="has-menu">
              <button class="nav-link" type="button" aria-expanded="false" aria-controls="menu-products">
                Products
                <svg class="chev" viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </button>
              <div class="dropdown" id="menu-products">
                <div class="dropdown-inner">
                  <div class="dropdown-intro">
                    <p class="dropdown-eyebrow">Online success platform</p>
                    <p class="dropdown-copy">Everything your business needs to win online, in one place.</p>
                  </div>
                  <div class="dropdown-cols">
                    <div class="dropdown-col">
                      <p class="dropdown-title">Presence</p>
                      <a href="{{ route('page.show', 'website') }}">Website</a>
                      <a href="{{ route('page.show', 'website-design') }}">Website Design</a>
                      <a href="{{ route('page.show', 'seo') }}">SEO Tool</a>
                      <a href="{{ route('page.show', 'google-my-business') }}">Google My Business</a>
                    </div>
                    <div class="dropdown-col">
                      <p class="dropdown-title">Promote</p>
                      <a href="{{ route('page.show', 'google-search-ads') }}">Google Search Ads</a>
                      <a href="{{ route('page.show', 'google-shopping-ads') }}">Google Shopping Ads</a>
                      <a href="{{ route('page.show', 'facebook-ads') }}">Facebook Advertising</a>
                      <a href="{{ route('page.show', 'instagram-ads') }}">Instagram Advertising</a>
                    </div>
                  </div>
                </div>
                <div class="dropdown-footer">
                  <p>Ready to grow? Our experts handle the marketing.</p>
                  <a class="btn btn-white btn-sm" href="{{ route('contact') }}">Talk to an expert</a>
                </div>
              </div>
            </li>
            <li><a class="nav-link" href="{{ route('pricing') }}">Pricing</a></li>
            <li><a class="nav-link" href="{{ route('press') }}">Blog</a></li>
            <li class="has-menu">
              <button class="nav-link" type="button" aria-expanded="false" aria-controls="menu-company">
                Company
                <svg class="chev" viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 4.5 6 8l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </button>
              <div class="dropdown dropdown--narrow" id="menu-company">
                <div class="dropdown-inner">
                  <div class="dropdown-col">
                    <a href="{{ route('about') }}">About us</a>
                    <a href="{{ route('careers') }}">Career</a>
                    <a href="{{ route('press') }}">Press</a>
                    <a href="{{ route('help') }}">Get help</a>
                  </div>
                </div>
              </div>
            </li>
          </ul>

          <div class="nav-cta">
            <a class="btn btn-ghost" href="{{ route('home') }}">Sign in</a>
            <a class="btn btn-primary" href="{{ route('pricing') }}">Get started</a>
          </div>
        </nav>

        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-nav" aria-label="Open menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </header>

  <main id="main">
    @yield('content')
  </main>

  <!-- ============ FOOTER ============ -->
  <footer class="site-footer" id="footer">
    <div class="container">
      <div class="footer-cols">
        <div class="footer-col">
          <h3>Presence</h3>
          <ul>
            <li><a href="{{ route('page.show', 'website') }}">Website</a></li>
            <li><a href="{{ route('page.show', 'website-design') }}">Website Design</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h3>Reach</h3>
          <ul>
            <li><a href="{{ route('page.show', 'seo') }}">SEO Tool</a></li>
            <li><a href="{{ route('page.show', 'google-my-business') }}">Google My Business</a></li>
            <li><a href="{{ route('page.show', 'marketing-analytics') }}">Marketing Analytics</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h3>Promote</h3>
          <ul>
            <li><a href="{{ route('page.show', 'google-search-ads') }}">Google Search Ads</a></li>
            <li><a href="{{ route('page.show', 'google-shopping-ads') }}">Google Shopping Ads</a></li>
            <li><a href="{{ route('page.show', 'facebook-ads') }}">Facebook Ads</a></li>
            <li><a href="{{ route('page.show', 'instagram-ads') }}">Instagram Ads</a></li>
          </ul>
        </div>
        <div class="footer-col">
          <h3>Company</h3>
          <ul>
            <li><a href="{{ route('about') }}">About us</a></li>
            <li><a href="{{ route('help') }}">Get help</a></li>
            <li><a href="{{ route('careers') }}">Career</a></li>
            <li><a href="{{ route('press') }}">Press &amp; Media</a></li>
          </ul>
        </div>
        <div class="footer-col footer-col--partner">
          <h3>Partnership</h3>
          <p class="partner-text">We are your Official Google Premier Partner and Meta Business Partner.</p>
          <div class="badges">
            <span class="badge">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27 3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10 5.35 0 9.25-3.67 9.25-9.09 0-1.15-.15-1.81-.15-1.81Z"/></svg>
              Google Premier Partner
            </span>
            <span class="badge">
              <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M24 12.07C24 5.44 18.63.07 12 .07S0 5.44 0 12.07c0 5.99 4.39 10.95 10.13 11.85v-8.38H7.08v-3.47h3.05V9.43c0-3.01 1.79-4.67 4.53-4.67 1.31 0 2.69.24 2.69.24v2.95h-1.51c-1.49 0-1.96.93-1.96 1.88v2.25h3.33l-.53 3.47h-2.8v8.38C19.61 23.02 24 18.06 24 12.07Z"/></svg>
              Meta Business Partner
            </span>
          </div>
          <div class="footer-social" aria-label="Social media">
            <a href="{{ route('page.show', 'facebook-ads') }}" aria-label="Facebook"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M24 12.07C24 5.44 18.63.07 12 .07S0 5.44 0 12.07c0 5.99 4.39 10.95 10.13 11.85v-8.38H7.08v-3.47h3.05V9.43c0-3.01 1.79-4.67 4.53-4.67 1.31 0 2.69.24 2.69.24v2.95h-1.51c-1.49 0-1.96.93-1.96 1.88v2.25h3.33l-.53 3.47h-2.8v8.38C19.61 23.02 24 18.06 24 12.07Z"/></svg></a>
            <a href="{{ route('page.show', 'instagram-ads') }}" aria-label="Instagram"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2.4" y="2.4" width="19.2" height="19.2" rx="5.6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4.4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.4" cy="6.6" r="1.3" fill="currentColor"/></svg></a>
            <a href="{{ route('page.show', 'google-search-ads') }}" aria-label="YouTube"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81ZM9.55 15.57V8.43L15.82 12l-6.27 3.57Z"/></svg></a>
            <a href="{{ route('about') }}" aria-label="LinkedIn"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28ZM5.34 7.43a2.07 2.07 0 1 1 0-4.13 2.07 2.07 0 0 1 0 4.13Zm1.78 13.02H3.56V9h3.56v11.45ZM22.22 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.73C24 .77 23.2 0 22.22 0Z"/></svg></a>
          </div>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <div class="container footer-bottom-inner">
        <p class="copyright">Copyright © {{ date('Y') }} WebServicers</p>
        <ul class="legal">
          <li><a href="{{ route('terms') }}">Terms of Service</a></li>
          <li><a href="{{ route('privacy') }}">Privacy Policy</a></li>
          <li><a href="{{ route('sitemap') }}">Sitemap</a></li>
        </ul>
      </div>
    </div>
  </footer>

  <script src="/assets/js/main.js" defer></script>
</body>
</html>
